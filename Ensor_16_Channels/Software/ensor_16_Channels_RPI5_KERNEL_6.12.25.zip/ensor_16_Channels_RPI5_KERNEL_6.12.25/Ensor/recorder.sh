#!/bin/sh


#sudo /home/rock/Ensor/master_8ch_32bit.py

# sudo shutdown -h now



