#!/bin/sh

/home/ensor/Ensor/ti.py mic_dif_ch1_ch4_2K5_48kHz_16.csv 1
arecord -D hw:0,0 -d 10 -c 2 -r 48000 -f S16_LE -v -t wav test_48kHz_16bits.wav
