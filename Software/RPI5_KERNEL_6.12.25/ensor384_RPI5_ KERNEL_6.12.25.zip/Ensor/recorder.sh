#!/bin/sh

sudo /home/ensor/Ensor/eea.py
sudo shutdown -h now
