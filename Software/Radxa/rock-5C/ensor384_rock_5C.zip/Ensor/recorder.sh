#!/bin/sh

#sudo /home/rock/Ensor/eea.py
#sudo /home/rock/Ensor/tdm.py

# sudo shutdown -h now

