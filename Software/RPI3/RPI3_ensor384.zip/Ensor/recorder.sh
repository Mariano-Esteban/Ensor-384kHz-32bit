#!/bin/sh

sudo /home/ensor/Ensor/eea.py
#sudo /home/ensor/Ensor/antena.py

sudo shutdown -h now

#systemctl poweroff  


